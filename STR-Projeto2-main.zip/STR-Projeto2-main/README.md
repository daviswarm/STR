# STR-Projeto2
Segundo projeto da disciplina de Sistemas de Tempo Real da Universidade de Brasília.
